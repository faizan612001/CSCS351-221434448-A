import static org.junit.Assert.*;
import org.junit.Test;
public class Main
{
  public static void main (String[]args)
  {
    @Test public void testAddFail ()
    {
      // assertNotEquals(String message, long expected, long actual)
      assertNotEquals ("error in add()", 0, Calculator.add (1, 2));
    };
  }
}
