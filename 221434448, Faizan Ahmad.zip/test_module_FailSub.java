import static org.junit.Assert.*;
import org.junit.Test;
public class Main
{
  public static void main (String[]args)
  {
    @Test public void testSubFail ()
    {
      assertNotEquals ("error in sub()", 0, Calculator.sub (2, 1));
    }
  }
