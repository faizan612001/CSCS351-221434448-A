import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
   
public class GradeUnitTest extends TestCase {
   
   public GradeUnitTest(String name) { super(name); }
   protected void setUp() throws Exception { super.setUp(); }
   protected void tearDown() throws Exception { super.tearDown(); }
   
   public void testTypical() {      // test a typical value in partitions
      assertEquals("wrong grade", 'A', Grade.getLetterGrade(95));
      assertEquals("wrong grade", 'B', Grade.getLetterGrade(72));
      assertEquals("wrong grade", 'C', Grade.getLetterGrade(55));
      assertEquals("wrong grade", 'F', Grade.getLetterGrade(30));
   }
   
   public void testBoundaries() {   // test the boundaries of the partitions
      assertEquals("wrong grade", 'A', Grade.getLetterGrade(75));
      assertEquals("wrong grade", 'A', Grade.getLetterGrade(100));
      assertEquals("wrong grade", 'B', Grade.getLetterGrade(60));
      assertEquals("wrong grade", 'B', Grade.getLetterGrade(74));
      assertEquals("wrong grade", 'C', Grade.getLetterGrade(50));
      assertEquals("wrong grade", 'C', Grade.getLetterGrade(59));
      assertEquals("wrong grade", 'F', Grade.getLetterGrade(0));
      assertEquals("wrong grade", 'F', Grade.getLetterGrade(49));
   }
   
   public static Test suite() {   // For putting into a TestSuite.
      return new TestSuite(GradeUnitTest.class);
   }
   
   public static void main(String[] args) {
      junit.textui.TestRunner.run(GradeUnitTest.class);
   }
}